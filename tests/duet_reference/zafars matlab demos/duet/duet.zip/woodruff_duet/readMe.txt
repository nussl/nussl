in matlab
load data.mat
DuetRefinement(sources,angle)
